﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class TeamPerformance
{
    private static List<TeamPerformance> _extent = new List<TeamPerformance>();

    public Team Team { get; set; }
    public int GoalsScored { get; set; }
    public int ShotsOnTarget { get; set; }
    public double BallPossession { get; set; } // Percentage (1–99)
    public double ExpectedGoals { get; set; } // (Expected Goals)

    public TeamPerformance(Team team, int goalsScored, int shotsOnTarget, double ballPossession, double expectedGoals)
    {
        if (team == null)
            throw new ArgumentException("Team cannot be null");
        if (ballPossession < 1 || ballPossession > 99)
            throw new ArgumentException("Ball possession must be between 1 and 99");
        if (goalsScored < 0 || shotsOnTarget < 0 || expectedGoals < 0)
            throw new ArgumentException("Performance stats cannot be negative");

        Team = team;
        GoalsScored = goalsScored;
        ShotsOnTarget = shotsOnTarget;
        BallPossession = ballPossession;
        ExpectedGoals = expectedGoals;

        _extent.Add(this);
    }

    public void DisplayPerformance()
    {
        Console.WriteLine($"Team: {Team.Name}");
        Console.WriteLine($"Goals Scored: {GoalsScored}");
        Console.WriteLine($"Shots On Target: {ShotsOnTarget}");
        Console.WriteLine($"Ball Possession: {BallPossession}%");
        Console.WriteLine($"Expected Goals (xG): {ExpectedGoals}");
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<TeamPerformance>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<TeamPerformance>));
        using var reader = new StreamReader(filePath);
        _extent = (List<TeamPerformance>)serializer.Deserialize(reader);
    }

    public static List<TeamPerformance> GetExtent() => new List<TeamPerformance>(_extent);

    public override string ToString()
    {
        return $"TeamPerformance(Team={Team.Name}, Goals={GoalsScored}, Shots={ShotsOnTarget}, Possession={BallPossession}%, xG={ExpectedGoals})";
    }
}
