﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class Substitution
{
    private static List<Substitution> _extent = new List<Substitution>();

    public Player GoingIn { get; set; }
    public Player GoingOut { get; set; }
    public string Reason { get; set; } // e.g., "Injury", "Tactical", "Timewasting"
    public DateTime TimeOfSubstitution { get; set; }
    public Match Match { get; set; }

    public Substitution(Player goingIn, Player goingOut, string reason, DateTime timeOfSubstitution, Match match)
    {
        if (goingIn == null || goingOut == null)
            throw new ArgumentException("Both players (GoingIn and GoingOut) must be specified");
        if (string.IsNullOrWhiteSpace(reason) || !new List<string> { "Injury", "Tactical", "Timewasting" }.Contains(reason))
            throw new ArgumentException("Invalid substitution reason");
        if (match == null)
            throw new ArgumentException("Substitution must be associated with a match");

        GoingIn = goingIn;
        GoingOut = goingOut;
        Reason = reason;
        TimeOfSubstitution = timeOfSubstitution;
        Match = match;

        _extent.Add(this);
    }

    public void RecordSubstitution()
    {
        Console.WriteLine($"Substitution in match {Match}: {GoingOut.Name} replaced by {GoingIn.Name} at {TimeOfSubstitution} due to {Reason}");
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Substitution>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Substitution>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Substitution>)serializer.Deserialize(reader);
    }

    public static List<Substitution> GetExtent() => new List<Substitution>(_extent);

    public override string ToString()
    {
        return $"Substitution(GoingOut={GoingOut.Name}, GoingIn={GoingIn.Name}, Reason={Reason}, Time={TimeOfSubstitution})";
    }
}
