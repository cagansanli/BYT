﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class Team
{
    private static List<Team> _extent = new List<Team>();

    public string Name { get; set; }

    [XmlIgnore]
    public Dictionary<string, double> TeamStats { get; set; } = new Dictionary<string, double>();

    [XmlElement("TeamStats")]
    public List<KeyValuePair<string, double>> SerializableTeamStats
    {
        get
        {
            var statsList = new List<KeyValuePair<string, double>>();
            foreach (var kvp in TeamStats)
            {
                statsList.Add(kvp);
            }
            return statsList;
        }
        set
        {
            TeamStats = new Dictionary<string, double>();
            foreach (var kvp in value)
            {
                TeamStats[kvp.Key] = kvp.Value;
            }
        }
    }

    public List<Player> Players { get; set; } = new List<Player>();

    public Coach Coach { get; set; }

    public Team() { }

    public Team(string name, Coach coach)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Team name cannot be empty");
        if (coach == null)
            throw new ArgumentException("A coach must be assigned to the team");

        Name = name;
        Coach = coach;
        _extent.Add(this);
    }

    public void ListPlayers()
    {
        Console.WriteLine($"Players in team {Name}:");
        foreach (var player in Players)
        {
            Console.WriteLine(player.ToString());
        }
    }

    public void ManagePlayers(Player player, bool add)
    {
        if (add)
        {
            if (!Players.Contains(player))
                Players.Add(player);
        }
        else
        {
            Players.Remove(player);
        }
    }

    public void ChooseLineup(int numberOfPlayers)
    {
        if (numberOfPlayers <= 0 || numberOfPlayers > Players.Count)
            throw new ArgumentException("Invalid number of players for the lineup");

        Console.WriteLine($"Lineup for team {Name}:");
        foreach (var player in Players.GetRange(0, numberOfPlayers))
        {
            Console.WriteLine(player.ToString());
        }
    }

    public void UpdateStats(string statName, double value)
    {
        if (string.IsNullOrWhiteSpace(statName))
            throw new ArgumentException("Stat name cannot be null or empty");

        if (!TeamStats.ContainsKey(statName))
        {
            TeamStats[statName] = 0;
        }

        TeamStats[statName] += value;
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Team>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Team>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Team>)serializer.Deserialize(reader);
    }

    public static List<Team> GetExtent() => new List<Team>(_extent);

    public override string ToString() => $"Team(Name={Name}, Coach={Coach?.ToString()})";
}
