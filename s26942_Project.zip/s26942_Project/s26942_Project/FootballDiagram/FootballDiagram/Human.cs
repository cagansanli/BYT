﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class Human
{
    private static List<Human> _extent = new List<Human>();

    public string Name { get; set; }
    public string MiddleName { get; set; } //optional
    public string Surname { get; set; }
    public int Age { get; set; }
    public string PhoneNumber { get; set; }
    public string Address { get; set; }

    public Human() { }

    public Human(string name, string surname, int age, string phoneNumber, string address, string middleName = null)
    {
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) || age <= 0 || string.IsNullOrWhiteSpace(phoneNumber) || string.IsNullOrWhiteSpace(address))
            throw new ArgumentException("Invalid input for Human attributes");

        Name = name;
        MiddleName = middleName;
        Surname = surname;
        Age = age;
        PhoneNumber = phoneNumber;
        Address = address;

        _extent.Add(this);
    }

    public void UpdateContactInfo(string phoneNumber, string address)
    {
        if (string.IsNullOrWhiteSpace(phoneNumber) || string.IsNullOrWhiteSpace(address))
            throw new ArgumentException("Contact information cannot be empty");

        PhoneNumber = phoneNumber;
        Address = address;
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Human>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Human>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Human>)serializer.Deserialize(reader);
    }

    public static List<Human> GetExtent() => new List<Human>(_extent);

    public override string ToString() => $"Human(Name={Name}, Surname={Surname}, Age={Age})";
}
