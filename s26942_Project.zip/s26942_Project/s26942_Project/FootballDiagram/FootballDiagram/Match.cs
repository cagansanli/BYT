﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class Match
{
    private static List<Match> _extent = new List<Match>();

    public DateTime Date { get; set; }
    public string Location { get; set; }
    public string MatchResult { get; set; }
    public List<Team> ParticipatingTeams { get; set; } = new List<Team>();

    public Match(DateTime date, string location, List<Team> teams)
    {
        if (teams == null || teams.Count != 2)
            throw new ArgumentException("A match must have exactly two participating teams");
        if (string.IsNullOrWhiteSpace(location))
            throw new ArgumentException("Location cannot be empty");

        Date = date;
        Location = location;
        ParticipatingTeams = teams;

        _extent.Add(this);
    }

    public void ScheduleMatch()
    {
        Console.WriteLine($"Match scheduled on {Date.ToShortDateString()} at {Location} between {ParticipatingTeams[0].Name} and {ParticipatingTeams[1].Name}.");
    }

    public void SaveResult(string result)
    {
        if (string.IsNullOrWhiteSpace(result))
            throw new ArgumentException("Match result cannot be empty");

        MatchResult = result;
        Console.WriteLine($"Result saved for the match: {result}");
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Match>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Match>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Match>)serializer.Deserialize(reader);
    }

    public static List<Match> GetExtent() => new List<Match>(_extent);

    public override string ToString()
    {
        return $"Match(Date={Date.ToShortDateString()}, Location={Location}, Teams={ParticipatingTeams[0].Name} vs {ParticipatingTeams[1].Name}, Result={MatchResult ?? "Pending"})";
    }
}
