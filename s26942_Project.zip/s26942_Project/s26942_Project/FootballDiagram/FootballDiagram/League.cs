﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class League
{
    private static List<League> _extent = new List<League>();

    public string Name { get; set; }
    public int PointsPerWin { get; set; }
    public int PointsPerDraw { get; set; }
    public int PointsPerLoss { get; set; }
    public List<Team> Teams { get; set; } = new List<Team>();

    public League(string name, int pointsPerWin = 3, int pointsPerDraw = 1, int pointsPerLoss = 0)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("League name cannot be empty");
        if (pointsPerWin < 0 || pointsPerDraw < 0 || pointsPerLoss < 0)
            throw new ArgumentException("Points values must be non-negative");

        Name = name;
        PointsPerWin = pointsPerWin;
        PointsPerDraw = pointsPerDraw;
        PointsPerLoss = pointsPerLoss;

        _extent.Add(this);
    }

    public void AddTeam(Team team)
    {
        if (team == null)
            throw new ArgumentException("Team cannot be null");

        if (!Teams.Contains(team))
            Teams.Add(team);
    }

    public void RemoveTeam(Team team)
    {
        if (team == null)
            throw new ArgumentException("Team cannot be null");

        Teams.Remove(team);
    }

    public void GetStandings()
    {
        Console.WriteLine($"Standings for League: {Name}");
        foreach (var team in Teams)
        {
            Console.WriteLine($"Team: {team.Name} - Statistics: {string.Join(", ", team.TeamStats)}");
        }
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<League>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<League>));
        using var reader = new StreamReader(filePath);
        _extent = (List<League>)serializer.Deserialize(reader);
    }

    public static List<League> GetExtent() => new List<League>(_extent);

    public override string ToString()
    {
        return $"League(Name={Name}, Teams={Teams.Count}, PointsPerWin={PointsPerWin}, PointsPerDraw={PointsPerDraw}, PointsPerLoss={PointsPerLoss})";
    }
}
