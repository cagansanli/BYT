﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class Player : Human
{
    private static List<Player> _extent = new List<Player>();

    public string Position { get; set; } //Goalkeeper, Defender, Midfielder, Forward
    public float Height { get; set; }
    public float Weight { get; set; }

    public Player() { }

    public Player(string name, string surname, int age, string phoneNumber, string address, string position, float height, float weight, string middleName = null)
        : base(name, surname, age, phoneNumber, address, middleName)
    {
        if (!new List<string> { "Goalkeeper", "Defender", "Midfielder", "Forward" }.Contains(position))
            throw new ArgumentException("Invalid position for Player");
        if (height <= 0 || weight <= 0)
            throw new ArgumentException("Height and weight must be positive values");

        Position = position;
        Height = height;
        Weight = weight;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Player>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Player>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Player>)serializer.Deserialize(reader);
    }

    public static List<Player> GetExtent() => new List<Player>(_extent);

    public override string ToString() => $"Player(Name={Name}, Position={Position}, Height={Height}, Weight={Weight})";
}
