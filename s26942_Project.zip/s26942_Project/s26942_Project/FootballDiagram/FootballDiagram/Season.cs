﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class Season
{
    private static List<Season> _extent = new List<Season>();

    public string Year { get; set; }
    public int NumberOfMatches => Matches.Count;
    public List<Match> Matches { get; set; } = new List<Match>();

    public Season(string year)
    {
        if (string.IsNullOrWhiteSpace(year) || year.Length != 4 || !int.TryParse(year, out _))
            throw new ArgumentException("Year must be a valid 4-digit number");

        Year = year;
        _extent.Add(this);
    }

    public void AddMatch(Match match)
    {
        if (match == null)
            throw new ArgumentException("Match cannot be null");

        Matches.Add(match);
    }

    public void RemoveMatch(Match match)
    {
        if (match == null)
            throw new ArgumentException("Match cannot be null");

        Matches.Remove(match);
    }

    public Team CalculateChampion()
    {
        Dictionary<Team, int> pointsTable = new Dictionary<Team, int>();

        foreach (var match in Matches)
        {
            if (match.MatchResult != null && match.ParticipatingTeams.Count == 2)
            {
                string[] resultParts = match.MatchResult.Split('-');
                string[] team1Data = resultParts[0].Split(':');
                string[] team2Data = resultParts[1].Split(':');

                Team team1 = match.ParticipatingTeams[0];
                Team team2 = match.ParticipatingTeams[1];

                int team1Score = int.Parse(team1Data[1]);
                int team2Score = int.Parse(team2Data[1]);

                if (!pointsTable.ContainsKey(team1)) pointsTable[team1] = 0;
                if (!pointsTable.ContainsKey(team2)) pointsTable[team2] = 0;

                if (team1Score > team2Score)
                {
                    pointsTable[team1] += 3;
                }
                else if (team1Score < team2Score)
                {
                    pointsTable[team2] += 3;
                }
                else
                {
                    pointsTable[team1] += 1;
                    pointsTable[team2] += 1;
                }
            }
        }

        Team champion = null;
        int maxPoints = 0;

        foreach (var team in pointsTable)
        {
            if (team.Value > maxPoints)
            {
                maxPoints = team.Value;
                champion = team.Key;
            }
        }

        return champion;
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Season>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Season>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Season>)serializer.Deserialize(reader);
    }

    public static List<Season> GetExtent() => new List<Season>(_extent);

    public override string ToString()
    {
        return $"Season(Year={Year}, NumberOfMatches={NumberOfMatches})";
    }
}
