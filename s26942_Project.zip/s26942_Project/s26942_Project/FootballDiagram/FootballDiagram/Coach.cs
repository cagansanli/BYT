﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

public class Coach : Human
{
    public string LicenseLevel { get; set; } // National A/B/C, International A/B/C

    [XmlIgnore]
    public Team Coaches { get; set; }

    [XmlElement("Coaches")]
    public string CoachesTeamName
    {
        get => Coaches?.Name;
        set { } 
    }

    public Coach() { }

    public Coach(string name, string surname, int age, string phoneNumber, string address, string licenseLevel, Team coaches = null, string middleName = null)
        : base(name, surname, age, phoneNumber, address, middleName)
    {
        if (string.IsNullOrWhiteSpace(licenseLevel) || !new List<string> { "National A", "National B", "National C", "International A", "International B", "International C" }.Contains(licenseLevel))
            throw new ArgumentException("Invalid license level for Coach");

        LicenseLevel = licenseLevel;
        Coaches = coaches;
    }

    public void AssignToTeam(Team team)
    {
        if (team == null)
            throw new ArgumentException("Team cannot be null");

        Coaches = team;
        Console.WriteLine($"{Name} {Surname} has been assigned to team {team.Name}.");
    }

    public override string ToString()
    {
        return $"Coach(Name={Name}, Surname={Surname}, LicenseLevel={LicenseLevel}, Coaches={Coaches?.Name ?? "None"})";
    }
}
