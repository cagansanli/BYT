using NUnit.Framework;
using FootballProject;
using System;
using System.Collections.Generic;

[TestFixture]
public class UnitTest1
{
    // Test Human Class
    [Test]
    public void Human_ValidAttributes_ShouldCreateInstance()
    {
        Human human = new Human("Cristiano", "Ronaldo", 38, "5551234567", "Riyadh");
        Assert.AreEqual("Cristiano", human.Name);
        Assert.AreEqual("Ronaldo", human.Surname);
        Assert.AreEqual(38, human.Age);
        Assert.AreEqual("Riyadh", human.Address);
    }

    [Test]
    public void Human_InvalidAttributes_ShouldThrowException()
    {
        Assert.Throws<ArgumentException>(() => new Human("", "Ronaldo", 38, "5551234567", "Riyadh"));
        Assert.Throws<ArgumentException>(() => new Human("Cristiano", "Ronaldo", -1, "5551234567", ""));
    }

    // Test Player Class
    [Test]
    public void Player_ValidAttributes_ShouldStoreInExtent()
    {
        Player player = new Player("Lionel", "Messi", 36, "5557654321", "Miami", "Forward", 170.0f, 72.0f);
        Assert.AreEqual("Lionel", player.Name);
        Assert.AreEqual("Forward", player.Position);
        Assert.Contains(player, Player.GetExtent());
    }

    [Test]
    public void Player_InvalidAttributes_ShouldThrowException()
    {
        Assert.Throws<ArgumentException>(() => new Player("Lionel", "Messi", 36, "5557654321", "Miami", "InvalidPosition", -1.0f, 72.0f));
    }

    // Test Coach Class
    [Test]
    public void Coach_ValidAttributes_ShouldAssignToTeam()
    {
        Coach coach = new Coach("Luis", "Enrique", 52, "5559876543", "Paris", "International A");
        Team team = new Team("Paris Saint-Germain", coach);
        Assert.AreEqual("Paris Saint-Germain", team.Name);
        Assert.AreEqual(coach, team.Coach);
    }

    [Test]
    public void Coach_InvalidAttributes_ShouldThrowException()
    {
        Assert.Throws<ArgumentException>(() => new Coach("Luis", "Enrique", 52, "5559876543", "Paris", "Invalid License"));
    }

    // Test League Class
    [Test]
    public void League_ValidAttributes_ShouldCreateInstance()
    {
        League league = new League("Premier League", 3, 1, 0);
        Assert.AreEqual("Premier League", league.Name);
        Assert.AreEqual(3, league.PointsPerWin);
        Assert.AreEqual(1, league.PointsPerDraw);
    }

    [Test]
    public void League_AddAndRemoveTeams_ShouldUpdateTeamsList()
    {
        League league = new League("Serie A", 3, 1, 0);
        Team juventus = new Team("Juventus", new Coach("Max", "Allegri", 53, "5557654321", "Turin", "International A"));
        Team inter = new Team("Inter Milan", new Coach("Simone", "Inzaghi", 47, "5559876543", "Milan", "National A"));

        league.AddTeam(juventus);
        league.AddTeam(inter);

        Assert.Contains(juventus, league.Teams);
        Assert.Contains(inter, league.Teams);

        league.RemoveTeam(juventus);
        Assert.IsFalse(league.Teams.Contains(juventus));
    }

    // Test Match Class
    [Test]
    public void Match_ValidAttributes_ShouldStoreMatchResult()
    {
        Team realMadrid = new Team("Real Madrid", new Coach("Carlo", "Ancelotti", 63, "5551234567", "Madrid", "International A"));
        Team barcelona = new Team("Barcelona", new Coach("Xavi", "Hernandez", 42, "5559876543", "Barcelona", "National A"));

        Match elClasico = new Match(DateTime.Now, "Camp Nou", new List<Team> { realMadrid, barcelona });
        elClasico.MatchResult = "Real Madrid:3-Barcelona:1";

        Assert.AreEqual("Real Madrid:3-Barcelona:1", elClasico.MatchResult);
    }

    // Test Card Class
    [Test]
    public void Card_ValidAttributes_ShouldLinkToPlayerAndMatch()
    {
        Player mbappe = new Player("Kylian", "Mbapp�", 24, "5557654321", "Paris", "Forward", 178.0f, 73.0f);
        Team psg = new Team("PSG", new Coach("Luis", "Enrique", 52, "5551234567", "Paris", "International A"));
        Team marseille = new Team("Marseille", new Coach("Igor", "Tudor", 45, "5559876543", "Marseille", "National A"));
        Match match = new Match(DateTime.Now, "Parc des Princes", new List<Team> { psg, marseille });
        Card yellowCard = new Card("Yellow", DateTime.Now, mbappe, match);
        Assert.AreEqual("Yellow", yellowCard.Type);
        Assert.AreEqual(mbappe, yellowCard.IssuedTo);
        Assert.AreEqual(match, yellowCard.IssuedIn);
    }

    // Test Referee Class
    [Test]
    public void Referee_ValidAttributes_ShouldStoreInExtent()
    {
        Referee referee = new Referee("Pierluigi", "Collina", 62, "5559876543", "Italy", 30);
        Assert.AreEqual("Pierluigi", referee.Name);
        Assert.AreEqual(30, referee.ExperienceLevel);
    }

    // Test Substitution Class
    [Test]
    public void Substitution_ValidAttributes_ShouldStoreInExtent()
    {
        Player playerOut = new Player("Angel", "Di Maria", 34, "5559871234", "Rosario", "Midfielder", 180.0f, 75.0f);
        Player playerIn = new Player("Julian", "Alvarez", 22, "5556543210", "Buenos Aires", "Forward", 175.0f, 70.0f);
        Team argentina = new Team("Argentina", new Coach("Lionel", "Scaloni", 43, "5556543210", "Buenos Aires", "National A"));
        Team france = new Team("France", new Coach("Didier", "Deschamps", 54, "5554321098", "Paris", "International A"));
        Match match = new Match(DateTime.Now, "Lusail Stadium", new List<Team> { argentina, france });

        Substitution substitution = new Substitution(playerIn, playerOut, "Tactical", DateTime.Now, match);

        Assert.AreEqual(playerIn, substitution.GoingIn);
        Assert.AreEqual(playerOut, substitution.GoingOut);
        Assert.AreEqual("Tactical", substitution.Reason);
    }
    // Test Season Class
    [Test]
    public void Season_CalculateChampion_ShouldReturnCorrectTeam()
    {
        Team manCity = new Team("Manchester City", new Coach("Pep", "Guardiola", 52, "5551234567", "Manchester", "International A"));
        Team arsenal = new Team("Arsenal", new Coach("Mikel", "Arteta", 40, "5557654321", "London", "National A"));

        Match match1 = new Match(DateTime.Now, "Etihad Stadium", new List<Team> { manCity, arsenal });
        match1.MatchResult = "Manchester City:3-Arsenal:0";

        Season season = new Season("2023");
        season.AddMatch(match1);

        Assert.AreEqual(manCity, season.CalculateChampion());
    }

    // Test TeamPerformance Class
    [Test]
    public void TeamPerformance_ValidAttributes_ShouldStoreCorrectValues()
    {
        Team team = new Team("Manchester City", new Coach("Pep", "Guardiola", 52, "5551234567", "Manchester", "International A"));
        TeamPerformance performance = new TeamPerformance(team, 3, 8, 65.5, 2.5);

        Assert.AreEqual(3, performance.GoalsScored);
        Assert.AreEqual(8, performance.ShotsOnTarget);
        Assert.AreEqual(65.5, performance.BallPossession);
        Assert.AreEqual(2.5, performance.ExpectedGoals);
    }
    //Test Team Class
    [Test]
    public void Team_ValidAttributes_ShouldCreateInstance()
    {
        Coach coach = new Coach("Pep", "Guardiola", 52, "5551234567", "Manchester", "International A");
        Team team = new Team("Manchester City", coach);

        Assert.AreEqual("Manchester City", team.Name);
        Assert.AreEqual(coach, team.Coach);
        Assert.IsEmpty(team.Players);
        Assert.IsEmpty(team.TeamStats);
    }

    [Test]
    public void Team_InvalidAttributes_ShouldThrowException()
    {
        Coach coach = new Coach("Jurgen", "Klopp", 55, "5559876543", "Liverpool", "International A");

        Assert.Throws<ArgumentException>(() => new Team("", coach)); 
        Assert.Throws<ArgumentException>(() => new Team("Liverpool FC", null)); 
    }

    [Test]
    public void Team_ManagePlayers_ShouldAddAndRemovePlayers()
    {
        Coach coach = new Coach("Mikel", "Arteta", 40, "5551112222", "London", "National A");
        Team team = new Team("Arsenal", coach);

        Player player1 = new Player("Bukayo", "Saka", 22, "5556543210", "London", "Forward", 178.0f, 72.0f);
        Player player2 = new Player("Gabriel", "Martinelli", 21, "5556543211", "London", "Forward", 176.0f, 70.0f);

        team.ManagePlayers(player1, true);
        team.ManagePlayers(player2, true);

        Assert.Contains(player1, team.Players);
        Assert.Contains(player2, team.Players);

        team.ManagePlayers(player1, false);
        Assert.IsFalse(team.Players.Contains(player1));
    }

    [Test]
    public void Team_ChooseLineup_ShouldPrintCorrectLineup()
    {
        Coach coach = new Coach("Carlo", "Ancelotti", 63, "5552223333", "Madrid", "International A");
        Team team = new Team("Real Madrid", coach);

        Player benzema = new Player("Karim", "Benzema", 35, "5554445555", "Madrid", "Forward", 185.0f, 81.0f);
        Player modric = new Player("Luka", "Modric", 37, "5556667777", "Madrid", "Midfielder", 172.0f, 66.0f);
        Player kroos = new Player("Toni", "Kroos", 33, "5558889999", "Madrid", "Midfielder", 183.0f, 76.0f);

        team.ManagePlayers(benzema, true);
        team.ManagePlayers(modric, true);
        team.ManagePlayers(kroos, true);

        using (var consoleOutput = new System.IO.StringWriter())
        {
            Console.SetOut(consoleOutput);
            team.ChooseLineup(2);

            string output = consoleOutput.ToString();
            Assert.IsTrue(output.Contains(benzema.ToString()));
            Assert.IsTrue(output.Contains(modric.ToString()));
            Assert.IsFalse(output.Contains(kroos.ToString()));
        }
    }

    [Test]
    public void Team_ListPlayers_ShouldPrintPlayerList()
    {
        Coach coach = new Coach("Thomas", "Tuchel", 49, "5553334444", "Munich", "International A");
        Team team = new Team("Bayern Munich", coach);

        Player mane = new Player("Sadio", "Man�", 31, "5551110000", "Munich", "Forward", 175.0f, 70.0f);
        Player kimmich = new Player("Joshua", "Kimmich", 28, "5554440000", "Munich", "Midfielder", 177.0f, 73.0f);

        team.ManagePlayers(mane, true);
        team.ManagePlayers(kimmich, true);

        using (var consoleOutput = new System.IO.StringWriter())
        {
            Console.SetOut(consoleOutput);
            team.ListPlayers();

            string output = consoleOutput.ToString();
            Assert.IsTrue(output.Contains(mane.ToString()));
            Assert.IsTrue(output.Contains(kimmich.ToString()));
        }
    }

    [Test]
    public void Team_UpdateStats_ShouldModifyTeamStats()
    {
        Coach coach = new Coach("Simone", "Inzaghi", 46, "5555556666", "Milan", "National A");
        Team team = new Team("Inter Milan", coach);

        team.TeamStats.Add("Points", 0);
        team.UpdateStats("Points", 3);

        Assert.AreEqual(3, team.TeamStats["Points"]);

        team.UpdateStats("Goals Scored", 2);
        Assert.AreEqual(2, team.TeamStats["Goals Scored"]);
    }

    [Test]
    public void Team_Extent_ShouldTrackTeams()
    {
        Coach coach = new Coach("Antonio", "Conte", 53, "5556667777", "London", "National A");
        Team team = new Team("Tottenham Hotspur", coach);

        List<Team> extent = Team.GetExtent();
        Assert.Contains(team, extent);
    }

    [Test]
    public void Team_Serialization_ShouldSaveAndLoadTeams()
    {
        string filePath = "teams_test.xml";
        typeof(Team).GetField("_extent", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
            ?.SetValue(null, new List<Team>());

        Coach coach = new Coach("Erik", "Ten Hag", 53, "5559998888", "Manchester", "International A");
        Team team = new Team("Manchester United", coach);

        Team.SaveToFile(filePath);
        Team.LoadFromFile(filePath);

        var loadedTeams = Team.GetExtent();
        Assert.AreEqual(1, loadedTeams.Count);
        Assert.AreEqual("Manchester United", loadedTeams[0].Name);
        Assert.AreEqual("Erik Ten Hag", $"{loadedTeams[0].Coach.Name} {loadedTeams[0].Coach.Surname}");
    }
}