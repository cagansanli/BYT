using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;

namespace FootballProject.Tests
{
    [TestFixture]
    public class UnitTests
    {
        private const string TestFilePath = "test_file.xml";

        [TearDown]
        public void Cleanup()
        {
            if (File.Exists(TestFilePath))
                File.Delete(TestFilePath);
        }

        // Tests for the Human class
        [Test]
        public void Human_InvalidAttributes_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() => new Human(null, "Sanli", 25, "123456789", "Address"));
            Assert.Throws<ArgumentException>(() => new Human("Cagan", null, 25, "123456789", "Address"));
            Assert.Throws<ArgumentException>(() => new Human("Cagan", "Sanli", -1, "123456789", "Address"));
            Assert.Throws<ArgumentException>(() => new Human("Cagan", "Sanli", 25, null, "Address"));
        }

        // Tests for the Player class
        [Test]
        public void Player_ValidAttributes_SuccessfullyCreated()
        {
            var player = new Player("Lionel", "Messi", 35, "987654321", "Paris, France",
                new List<string> { "Forward" }, 1.70f, 67.0f);
            Assert.AreEqual("Lionel", player.Name);
            Assert.Contains("Forward", player.Positions);
        }

        [Test]
        public void Player_InvalidPosition_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new Player("Lionel", "Messi", 35, "987654321", "Paris, France",
                new List<string> { "InvalidPosition" }, 1.70f, 67.0f));
        }

        // Tests for the Team class
        [Test]
        public void Team_ValidAttributes_SuccessfullyCreated()
        {
            var coach = new Coach("Pep", "Guardiola", 50, "111222333", "Manchester, UK", "National A");
            var team = new Team("Manchester City", coach);
            Assert.AreEqual("Manchester City", team.Name);
            Assert.AreEqual(coach, team.Coach);
        }

        [Test]
        public void Team_EmptyName_ThrowsException()
        {
            var coach = new Coach("Jurgen", "Klopp", 54, "444555666", "Liverpool, UK", "National A");
            Assert.Throws<ArgumentException>(() => new Team(null, coach));
        }

        // Tests for the Match class
        [Test]
        public void Match_ValidAttributes_SuccessfullyCreated()
        {
            var team1 = new Team("Real Madrid", new Coach("Carlo", "Ancelotti", 60, "888999000", "Madrid, Spain", "International A"));
            var team2 = new Team("Barcelona", new Coach("Xavi", "Hernandez", 42, "777888999", "Barcelona, Spain", "National A"));
            var match = new Match(DateTime.Now, "Camp Nou", new List<Team> { team1, team2 });
            Assert.AreEqual(2, match.ParticipatingTeams.Count);
        }

        [Test]
        public void Match_OneTeam_ThrowsException()
        {
            var team1 = new Team("Real Madrid", new Coach("Carlo", "Ancelotti", 60, "888999000", "Madrid, Spain", "International A"));
            Assert.Throws<ArgumentException>(() => new Match(DateTime.Now, "Camp Nou", new List<Team> { team1 }));
        }

        // Card Class Tests
        [Test]
        public void Card_ValidAttributes_SuccessfullyCreated()
        {
            var player = new Player("Cristiano", "Ronaldo", 37, "123456789", "Riyadh, Saudi Arabia",
                new List<string> { "Forward" }, 1.87f, 84.0f);
            var match = new Match(DateTime.Now, "Stadium A", new List<Team>
            {
                new Team("Team A", new Coach("Coach A", "Surname", 45, "987654321", "City A", "National A")),
                new Team("Team B", new Coach("Coach B", "Surname", 50, "123987456", "City B", "International A"))
            });
            var card = new Card("Yellow", DateTime.Now, player, match);

            Assert.AreEqual("Yellow", card.Type);
            Assert.AreEqual(player, card.IssuedTo);
        }

        [Test]
        public void Card_InvalidType_ThrowsException()
        {
            var player = new Player("Lionel", "Messi", 35, "987654321", "Paris, France",
                new List<string> { "Forward" }, 1.70f, 67.0f);
            var match = new Match(DateTime.Now, "Stadium B", new List<Team>
            {
                new Team("Team C", new Coach("Coach C", "Surname", 55, "147258369", "City C", "National B")),
                new Team("Team D", new Coach("Coach D", "Surname", 48, "789456123", "City D", "International B"))
            });
            Assert.Throws<ArgumentException>(() => new Card("Blue", DateTime.Now, player, match));


            [Test]
            void Card_InvalidType_ThrowsException()
            {
                var player = new Player("Lionel", "Messi", 35, "987654321", "Paris, France",
                    new List<string> { "Forward" }, 1.70f, 67.0f);
                var match = new Match(DateTime.Now, "Stadium B", new List<Team>
            {
                new Team("Team C", new Coach("Coach C", "Surname", 55, "147258369", "City C", "National B")),
                new Team("Team D", new Coach("Coach D", "Surname", 48, "789456123", "City D", "International B"))
            });
                Assert.Throws<ArgumentException>(() => new Card("Blue", DateTime.Now, player, match));
            }
        }

        // Substitution Class Tests
        [Test]
        public void Substitution_ValidAttributes_SuccessfullyCreated()
        {
            var playerIn = new Player("Neymar", "Junior", 30, "789456123", "Paris, France",
                new List<string> { "Midfielder" }, 1.75f, 68.0f);
            var playerOut = new Player("Angel", "Di Maria", 34, "456123789", "Paris, France",
                new List<string> { "Forward" }, 1.80f, 70.0f);
            var match = new Match(DateTime.Now, "Parc des Princes", new List<Team>
            {
                new Team("PSG", new Coach("Coach PSG", "Surname", 50, "147258369", "Paris", "International A")),
                new Team("OM", new Coach("Coach OM", "Surname", 45, "369258147", "Marseille", "National A"))
            });
            var substitution = new Substitution(playerIn, playerOut, "Injury", DateTime.Now, match);

            Assert.AreEqual("Injury", substitution.Reason);
            Assert.AreEqual(playerIn, substitution.GoingIn);
            Assert.AreEqual(playerOut, substitution.GoingOut);
        }

        [Test]
        public void Substitution_InvalidReason_ThrowsException()
        {
            var playerIn = new Player("Player A", "Surname", 28, "789123456", "City A",
                new List<string> { "Defender" }, 1.85f, 80.0f);
            var playerOut = new Player("Player B", "Surname", 29, "123456789", "City B",
                new List<string> { "Goalkeeper" }, 1.90f, 85.0f);
            var match = new Match(DateTime.Now, "Stadium A", new List<Team>
            {
                new Team("Team X", new Coach("Coach X", "Surname", 48, "123987456", "City X", "National A")),
                new Team("Team Y", new Coach("Coach Y", "Surname", 52, "987321654", "City Y", "International A"))
            });
            Assert.Throws<ArgumentException>(() => new Substitution(playerIn, playerOut, "UnknownReason", DateTime.Now, match));
        }

        // TeamPerformance Class Tests
        [Test]
        public void TeamPerformance_ValidAttributes_SuccessfullyCreated()
        {
            var team = new Team("Real Madrid", new Coach("Carlo", "Ancelotti", 62, "789456123", "Madrid", "International A"));
            var performance = new TeamPerformance(team, 3, 8, 65.5, 2.8);

            Assert.AreEqual(team, performance.Team);
            Assert.AreEqual(3, performance.GoalsScored);
            Assert.AreEqual(65.5, performance.BallPossession);
        }

        [Test]
        public void TeamPerformance_InvalidBallPossession_ThrowsException()
        {
            var team = new Team("Barcelona", new Coach("Xavi", "Hernandez", 42, "123456789", "Barcelona", "National A"));
            Assert.Throws<ArgumentException>(() => new TeamPerformance(team, 2, 7, 150.0, 3.0));
        }

        // League Class Tests
        [Test]
        public void League_ValidAttributes_SuccessfullyCreated()
        {
            var league = new League("La Liga", 3, 1, 0);
            Assert.AreEqual("La Liga", league.Name);
            Assert.AreEqual(3, league.PointsPerWin);
        }

        [Test]
        public void League_NegativePoints_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() => new League("Serie A", -3, 1, 0));
        }

        // Season Class Tests
        [Test]
        public void Season_ValidAttributes_SuccessfullyCreated()
        {
            var season = new Season("2024");
            Assert.AreEqual("2024", season.Year);
        }

        [Test]
        public void Season_InvalidYear_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() => new Season("InvalidYear"));
        }

        [Test]
        public void Season_NumberOfMatches_DerivedSuccessfully()
        {
            var team1 = new Team("Team A", new Coach("Coach A", "Surname", 45, "123456789", "City A", "National A"));
            var team2 = new Team("Team B", new Coach("Coach B", "Surname", 50, "987654321", "City B", "International A"));
            var match1 = new Match(DateTime.Now, "Stadium A", new List<Team> { team1, team2 });
            var match2 = new Match(DateTime.Now, "Stadium B", new List<Team> { team1, team2 });

            var season = new Season("2024");
            season.Matches.Add(match1);
            season.Matches.Add(match2);

            Assert.AreEqual(2, season.NumberOfMatches);
        }
        // Referee Class Tests
        [Test]
        public void Referee_ValidAttributes_SuccessfullyCreated()
        {
            var referee = new Referee("Pierluigi", "Collina", 45, "123456789", "Rome, Italy", 3);
            Assert.AreEqual("Pierluigi", referee.Name);
            Assert.AreEqual(3, referee.ExperienceLevel); // Experienced
        }

        [Test]
        public void Referee_InvalidExperienceLevel_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() => new Referee("Mike", "Dean", 50, "987654321", "London, UK", 0));
            Assert.Throws<ArgumentException>(() => new Referee("Howard", "Webb", 52, "456123789", "Manchester, UK", 4));
        }

        // Serialization for Referee
        [Test]
        public void Serialization_Referee_SuccessfullySavedAndLoaded()
        {
            var referee = new Referee("Pierluigi", "Collina", 45, "123456789", "Rome, Italy", 3);
            Referee.SaveToFile(TestFilePath);

            Referee.LoadFromFile(TestFilePath);
            var loadedReferees = Referee.GetExtent();

            Assert.AreEqual(1, loadedReferees.Count);
            Assert.AreEqual("Pierluigi", loadedReferees[0].Name);
        }

        // Coach Class Tests
        [Test]
        public void Coach_ValidAttributes_SuccessfullyCreated()
        {
            var team = new Team("Manchester City", null);
            var coach = new Coach("Pep", "Guardiola", 50, "123456789", "Manchester, UK", "International A", team);
            Assert.AreEqual("Pep", coach.Name);
            Assert.AreEqual("International A", coach.LicenseLevel);
            Assert.AreEqual(team, coach.Coaches);
        }

        [Test]
        public void Coach_InvalidLicenseLevel_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new Coach("Jose", "Mourinho", 58, "987654321", "Rome, Italy", "Invalid License"));
        }

        // Serialization for Coach
        [Test]
        public void Serialization_Coach_SuccessfullySavedAndLoaded()
        {
            var coach = new Coach("Carlo", "Ancelotti", 60, "789456123", "Madrid, Spain", "International A");
            Coach.SaveToFile(TestFilePath);

            Coach.LoadFromFile(TestFilePath);
            var loadedCoaches = Coach.GetExtent();

            Assert.AreEqual(1, loadedCoaches.Count);
            Assert.AreEqual("Carlo", loadedCoaches[0].Name);
        }
    }
}