﻿namespace FootballProject;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Coach : Human
{
    private static List<Coach> _extent = new List<Coach>();

    public string LicenseLevel { get; set; } // National A/B/C, International A/B/C

    [XmlIgnore]
    public Team Coaches { get; set; }

    [XmlElement("Coaches")]
    public string CoachesTeamName
    {
        get => Coaches?.Name;
        set { }
    }

    public Coach(string name, string surname, int age, string phoneNumber, string address, string licenseLevel, Team coaches = null, string middleName = null)
        : base(name, surname, age, phoneNumber, address, middleName)
    {
        if (string.IsNullOrWhiteSpace(licenseLevel) || !new List<string> { "National A", "National B", "National C", "International A", "International B", "International C" }.Contains(licenseLevel))
            throw new ArgumentException("Invalid license level for Coach");

        LicenseLevel = licenseLevel;
        Coaches = coaches;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Coach>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Coach>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Coach>)serializer.Deserialize(reader);
    }

    public static List<Coach> GetExtent() => new List<Coach>(_extent);
}
