﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Card
{
    private static List<Card> _extent = new List<Card>();

    public string Type { get; set; } // "Yellow" or "Red"
    public DateTime TimeIssued { get; set; }
    public Player IssuedTo { get; set; }
    public Match IssuedIn { get; set; }

    public Card(string type, DateTime timeIssued, Player issuedTo, Match issuedIn)
    {
        if (string.IsNullOrWhiteSpace(type) || !new List<string> { "Yellow", "Red" }.Contains(type))
            throw new ArgumentException("Invalid card type. Must be 'Yellow' or 'Red'.");
        if (issuedTo == null)
            throw new ArgumentException("A card must be issued to a player.");
        if (issuedIn == null)
            throw new ArgumentException("A card must be issued in a match.");

        Type = type;
        TimeIssued = timeIssued;
        IssuedTo = issuedTo;
        IssuedIn = issuedIn;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Card>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Card>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Card>)serializer.Deserialize(reader);
    }

    public static List<Card> GetExtent() => new List<Card>(_extent);
}
