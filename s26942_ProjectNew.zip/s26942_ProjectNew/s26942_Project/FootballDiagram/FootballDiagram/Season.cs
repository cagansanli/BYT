﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Season
{
    private static List<Season> _extent = new List<Season>();

    public string Year { get; set; }

    [XmlIgnore]
    public int NumberOfMatches => Matches.Count; // Derived attribute based on the number of matches

    public List<Match> Matches { get; set; } = new List<Match>();

    public Season(string year)
    {
        if (string.IsNullOrWhiteSpace(year) || year.Length != 4 || !int.TryParse(year, out _))
            throw new ArgumentException("Year must be a valid 4-digit number.");

        Year = year;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Season>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found.");

        var serializer = new XmlSerializer(typeof(List<Season>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Season>)serializer.Deserialize(reader);
    }

    public static List<Season> GetExtent() => new List<Season>(_extent);
}
