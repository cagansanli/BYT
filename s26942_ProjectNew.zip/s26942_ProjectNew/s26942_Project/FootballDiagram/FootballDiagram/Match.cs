﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Match
{
    private static List<Match> _extent = new List<Match>();

    public DateTime Date { get; set; }
    public string Location { get; set; }
    public string MatchResult { get; set; }
    public List<Team> ParticipatingTeams { get; set; } = new List<Team>();

    public Match(DateTime date, string location, List<Team> teams)
    {
        if (teams == null || teams.Count != 2)
            throw new ArgumentException("A match must have exactly two participating teams.");
        if (string.IsNullOrWhiteSpace(location))
            throw new ArgumentException("Location cannot be empty.");

        Date = date;
        Location = location;
        ParticipatingTeams = teams;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Match>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found.");

        var serializer = new XmlSerializer(typeof(List<Match>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Match>)serializer.Deserialize(reader);
    }

    public static List<Match> GetExtent() => new List<Match>(_extent);
}
