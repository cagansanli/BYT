﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Team
{
    private static List<Team> _extent = new List<Team>();

    public string Name { get; set; }

    [XmlIgnore]
    public Dictionary<string, double> TeamStats { get; set; } = new Dictionary<string, double>();

    [XmlElement("TeamStats")]
    public List<KeyValuePair<string, double>> SerializableTeamStats
    {
        get
        {
            var statsList = new List<KeyValuePair<string, double>>();
            foreach (var kvp in TeamStats)
            {
                statsList.Add(kvp);
            }
            return statsList;
        }
        set
        {
            TeamStats = new Dictionary<string, double>();
            foreach (var kvp in value)
            {
                TeamStats[kvp.Key] = kvp.Value;
            }
        }
    }

    public List<Player> Players { get; set; } = new List<Player>();

    public Coach Coach { get; set; }

    public Team(string name, Coach coach)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Team name cannot be empty");
        if (coach == null)
            throw new ArgumentException("A coach must be assigned to the team");

        Name = name;
        Coach = coach;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Team>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Team>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Team>)serializer.Deserialize(reader);
    }

    public static List<Team> GetExtent() => new List<Team>(_extent);
}
