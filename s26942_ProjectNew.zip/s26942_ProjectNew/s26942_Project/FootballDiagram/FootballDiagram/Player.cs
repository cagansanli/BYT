﻿namespace FootballProject;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Player : Human
{
    private static List<Player> _extent = new List<Player>();

    [XmlArray("Positions")]
    [XmlArrayItem("Position")]
    public List<string> Positions { get; set; } = new List<string>(); // Multivalue

    public float Height { get; set; }
    public float Weight { get; set; }

    public Player(string name, string surname, int age, string phoneNumber, string address, List<string> positions, float height, float weight, string middleName = null)
        : base(name, surname, age, phoneNumber, address, middleName)
    {
        if (positions == null || positions.Count < 1 || positions.Count > 3)
            throw new ArgumentException("A player must have between 1 and 3 positions.");
        foreach (var position in positions)
        {
            if (!new List<string> { "Goalkeeper", "Defender", "Midfielder", "Forward" }.Contains(position))
                throw new ArgumentException("Invalid position for Player");
        }
        if (height <= 0 || weight <= 0)
            throw new ArgumentException("Height and weight must be positive values");

        Positions = positions;
        Height = height;
        Weight = weight;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Player>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Player>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Player>)serializer.Deserialize(reader);
    }

    public static List<Player> GetExtent() => new List<Player>(_extent);
}
