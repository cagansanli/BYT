﻿namespace FootballProject;

using System;
using System.Collections.Generic;

public class Human
{
    public string Name { get; set; }
    public string MiddleName { get; set; } //optional
    public string Surname { get; set; }
    public int Age { get; set; }
    public string PhoneNumber { get; set; }
    public string Address { get; set; }

    public Human(string name, string surname, int age, string phoneNumber, string address, string middleName = null)
    {
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) || age <= 0 || string.IsNullOrWhiteSpace(phoneNumber) || string.IsNullOrWhiteSpace(address))
            throw new ArgumentException("Invalid input for Human attributes");

        Name = name;
        MiddleName = middleName;
        Surname = surname;
        Age = age;
        PhoneNumber = phoneNumber;
        Address = address;
    }
}
