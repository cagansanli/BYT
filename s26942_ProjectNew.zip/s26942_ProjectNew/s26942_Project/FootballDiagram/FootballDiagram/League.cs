﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class League
{
    private static List<League> _extent = new List<League>();

    public string Name { get; set; }
    public int PointsPerWin { get; set; }
    public int PointsPerDraw { get; set; }
    public int PointsPerLoss { get; set; }
    public List<Team> Teams { get; set; } = new List<Team>();

    public League(string name, int pointsPerWin = 3, int pointsPerDraw = 1, int pointsPerLoss = 0)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("League name cannot be empty.");
        if (pointsPerWin < 0 || pointsPerDraw < 0 || pointsPerLoss < 0)
            throw new ArgumentException("Points values must be postive.");

        Name = name;
        PointsPerWin = pointsPerWin;
        PointsPerDraw = pointsPerDraw;
        PointsPerLoss = pointsPerLoss;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<League>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found.");

        var serializer = new XmlSerializer(typeof(List<League>));
        using var reader = new StreamReader(filePath);
        _extent = (List<League>)serializer.Deserialize(reader);
    }

    public static List<League> GetExtent() => new List<League>(_extent);
}
