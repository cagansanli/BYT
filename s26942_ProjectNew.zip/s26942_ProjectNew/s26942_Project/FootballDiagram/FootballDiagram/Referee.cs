﻿namespace FootballProject;

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Referee : Human
{
    private static List<Referee> _extent = new List<Referee>();

    public int ExperienceLevel { get; set; } // Values: 1, 2, 3 (Beginner, Intermediate, Expereinced)

    public Referee(string name, string surname, int age, string phoneNumber, string address, int experienceLevel, string middleName = null)
        : base(name, surname, age, phoneNumber, address, middleName)
    {
        if (!new List<int> { 1, 2, 3 }.Contains(experienceLevel))
            throw new ArgumentException("Expereince level must be 1 (Beginner), 2 (Intermediate), or 3 (Experienced)");

        ExperienceLevel = experienceLevel;

        _extent.Add(this);
    }

    public static void SaveToFile(string filePath)
    {
        var serializer = new XmlSerializer(typeof(List<Referee>));
        using var writer = new StreamWriter(filePath);
        serializer.Serialize(writer, _extent);
    }

    public static void LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"File {filePath} not found");

        var serializer = new XmlSerializer(typeof(List<Referee>));
        using var reader = new StreamReader(filePath);
        _extent = (List<Referee>)serializer.Deserialize(reader);
    }

    public static List<Referee> GetExtent() => new List<Referee>(_extent);
}
